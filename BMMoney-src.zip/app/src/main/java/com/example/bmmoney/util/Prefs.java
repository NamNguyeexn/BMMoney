package com.example.bmmoney.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Calendar;

/** Luu ten nguoi dung, ngan sach, ngay chot chu ky, danh muc va thoi diem sao luu. */
public final class Prefs {

    private static final String FILE = "bmm_settings";
    private static final String KEY_NAME = "user_name";
    private static final String KEY_BUDGET = "monthly_budget";
    private static final String KEY_BACKUP = "last_backup";
    private static final String KEY_CYCLE_DAY = "cycle_day";
    private static final String KEY_CYCLE_MONTH = "cycle_month";
    private static final String KEY_CATEGORIES = "categories";
    private static final String KEY_WARN_PERCENT = "warn_percent";
    private static final String KEY_BIG_PERCENT = "big_percent";
    private static final String KEY_REMINDERS = "reminders";
    private static final String KEY_ONBOARDED = "onboarded";
    private static final String KEY_AUTO_BACKUP_DAY = "auto_backup_day";
    private static final String KEY_LEGACY_CLEANED = "legacy_cleaned";
    private static final String KEY_STRONG_ALARM = "strong_alarm";
    /** Ban va 03/08: moc thoi gian du lieu duoi may doi lan cuoi (de so voi cloud). */
    private static final String KEY_LOCAL_CHANGED = "local_changed";

    public static final double DEFAULT_BUDGET = 80500000d;

    private Prefs() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static String userName(Context context) {
        return prefs(context).getString(KEY_NAME, "b\u1ea1n");
    }

    public static void setUserName(Context context, String name) {
        prefs(context).edit().putString(KEY_NAME, name).apply();
        markChanged(context);
    }

    public static double budget(Context context) {
        return prefs(context).getFloat(KEY_BUDGET, (float) DEFAULT_BUDGET);
    }

    public static void setBudget(Context context, double budget) {
        prefs(context).edit().putFloat(KEY_BUDGET, (float) budget).apply();
        markChanged(context);
    }

    /**
     * Ban va 03/08. Lan cuoi du lieu duoi may thay doi.
     *
     * <p>Dung de nut Dong bo biet nen day len hay keo ve: neu may moi hon cloud
     * thi sao luu de, con cloud moi hon thi lay ve.</p>
     */
    public static long localChangedAt(Context context) {
        return prefs(context).getLong(KEY_LOCAL_CHANGED, 0L);
    }

    public static void setLocalChangedAt(Context context, long time) {
        prefs(context).edit().putLong(KEY_LOCAL_CHANGED, time).apply();
    }

    /** Danh dau du lieu duoi may vua doi ngay bay gio. */
    public static void touchLocal(Context context) {
        setLocalChangedAt(context, System.currentTimeMillis());
    }

    public static long lastBackup(Context context) {
        return prefs(context).getLong(KEY_BACKUP, 0L);
    }

    public static void setLastBackup(Context context, long time) {
        prefs(context).edit().putLong(KEY_BACKUP, time).apply();
    }

    /** Ngay chot chu ky (1..31). */
    public static int cycleDay(Context context) {
        return prefs(context).getInt(KEY_CYCLE_DAY, 1);
    }

    /** Thang moc cua chu ky (1..12), chi dung de hien thi dd/mm. */
    public static int cycleMonth(Context context) {
        int fallback = Calendar.getInstance().get(Calendar.MONTH) + 1;
        return prefs(context).getInt(KEY_CYCLE_MONTH, fallback);
    }

    public static void setCycle(Context context, int day, int month) {
        prefs(context).edit()
                .putInt(KEY_CYCLE_DAY, Math.max(1, Math.min(31, day)))
                .putInt(KEY_CYCLE_MONTH, Math.max(1, Math.min(12, month)))
                .apply();
        markChanged(context);
    }

    public static String categoriesRaw(Context context) {
        return prefs(context).getString(KEY_CATEGORIES, null);
    }

    public static void setCategoriesRaw(Context context, String raw) {
        prefs(context).edit().putString(KEY_CATEGORIES, raw).apply();
        markChanged(context);
    }

    /** Nguong canh bao chi tieu (% ngan sach), mac dinh 90%. */
    public static int warnPercent(Context context) {
        return prefs(context).getInt(KEY_WARN_PERCENT, 90);
    }

    public static void setWarnPercent(Context context, int percent) {
        prefs(context).edit().putInt(KEY_WARN_PERCENT, clamp(percent, 10, 200)).apply();
        markChanged(context);
    }

    /** Moc "khoan chi dang chu y": giao dich chiem tu x% tong chi cua ky, mac dinh 15%. */
    public static int bigPercent(Context context) {
        return prefs(context).getInt(KEY_BIG_PERCENT, 15);
    }

    public static void setBigPercent(Context context, int percent) {
        prefs(context).edit().putInt(KEY_BIG_PERCENT, clamp(percent, 1, 99)).apply();
        markChanged(context);
    }

    public static String remindersRaw(Context context) {
        return prefs(context).getString(KEY_REMINDERS, null);
    }

    public static void setRemindersRaw(Context context, String raw) {
        prefs(context).edit().putString(KEY_REMINDERS, raw).apply();
        markChanged(context);
    }

    /** Da qua popup Xin chao lan dau chua. */
    public static boolean onboarded(Context context) {
        return prefs(context).getBoolean(KEY_ONBOARDED, false);
    }

    public static void setOnboarded(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_ONBOARDED, value).apply();
    }

    /** Ngay da tu dong sao luu gan nhat, dang yyyyMMdd. */
    public static int autoBackupDay(Context context) {
        return prefs(context).getInt(KEY_AUTO_BACKUP_DAY, 0);
    }

    public static void setAutoBackupDay(Context context, int day) {
        prefs(context).edit().putInt(KEY_AUTO_BACKUP_DAY, day).apply();
    }

    /** Da don xong cac ban ghi cloud kieu cu (moi giao dich mot document) chua. */
    public static boolean legacyCleaned(Context context) {
        return prefs(context).getBoolean(KEY_LEGACY_CLEANED, false);
    }

    public static void setLegacyCleaned(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_LEGACY_CLEANED, value).apply();
    }

    /**
     * Ban va 04/08: do uu tien bao thuc nhac nho.
     *
     * <p>true (mac dinh) = dat bang setAlarmClock, cung muc uu tien voi bao thuc cua
     * dong ho he thong. He thong khong duoc phep hoan hay dong bang no. Doi lai, thanh
     * trang thai hien mot bieu tuong dong ho nho.</p>
     *
     * <p>false = bao thuc thuong. Khong co bieu tuong, nhung trong che do Doze co the
     * bi don sang cua so bao tri va tre hang gio.</p>
     *
     * <p>Ca hai che do deu KHONG ton pin khi cho: app khong he chay.</p>
     */
    public static boolean strongAlarm(Context context) {
        return prefs(context).getBoolean(KEY_STRONG_ALARM, true);
    }

    public static void setStrongAlarm(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_STRONG_ALARM, value).apply();
        markChanged(context);
    }

    /**
     * Ban va 04/08: moi thay doi CAI DAT cung phai danh dau la "du lieu duoi may vua
     * doi", y nhu khi them mot giao dich.
     *
     * <p>Truoc day chi co giao dich moi goi touchLocal. Hai he qua:</p>
     * <ul>
     *   <li>Doi ten, ngan sach, danh muc, nguong hay gio nhac xong thi khong co gi
     *       day len cloud - phai cho den khi tinh co them mot giao dich.</li>
     *   <li>Nang hon: vi moc localChangedAt khong nhich, lan bam Dong bo ke tiep
     *       thay cloud MOI HON may nen KEO CLOUD VE, ghi de dung nhung cai dat vua
     *       nhap. Day la ly do co cam giac "cai dat khong luu duoc".</li>
     * </ul>
     *
     * <p>Khi khoi phuc tu cloud, cac setter nay cung chay va cung goi markChanged,
     * nhung restoreLatest ghi lai localChangedAt = moc cua ban cloud NGAY SAU DO,
     * nen khong sinh ra vong day-keo lan nhau.</p>
     */
    private static void markChanged(Context context) {
        touchLocal(context);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
